package com.pixhawk.gcslite.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.SettingsApplications
import androidx.compose.ui.graphics.vector.ImageVector

enum class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    CONNECT("connect", "Connect", Icons.Default.Cable),
    FLY("fly", "Fly", Icons.Default.FlightTakeoff),
    MISSIONS("missions", "Missions", Icons.Default.Assignment),
    PARAMS("params", "Params", Icons.Default.SettingsApplications),
    LOGS("logs", "Logs", Icons.Default.Description),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}