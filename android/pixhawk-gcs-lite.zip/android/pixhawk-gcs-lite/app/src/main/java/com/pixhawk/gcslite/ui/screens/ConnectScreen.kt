package com.pixhawk.gcslite.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.pixhawk.gcslite.R
import com.pixhawk.gcslite.data.connection.ConnectionManager
import com.pixhawk.gcslite.data.connection.ConnectionState
import com.pixhawk.gcslite.data.connection.UdpConnectionConfig

@Composable
fun ConnectScreen(
    modifier: Modifier = Modifier
) {
    val connectionManager = remember { ConnectionManager() }
    val connectionState by connectionManager.connectionState.collectAsState()
    
    var host by remember { mutableStateOf("127.0.0.1") }
    var port by remember { mutableStateOf("14550") }
    
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = stringResource(R.string.connect_title),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "UDP Configuration",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    label = { Text(stringResource(R.string.connect_host_label)) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = connectionState == ConnectionState.DISCONNECTED
                )
                
                OutlinedTextField(
                    value = port,
                    onValueChange = { port = it },
                    label = { Text(stringResource(R.string.connect_port_label)) },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    enabled = connectionState == ConnectionState.DISCONNECTED
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            if (connectionState == ConnectionState.DISCONNECTED || 
                                connectionState == ConnectionState.ERROR) {
                                val config = UdpConnectionConfig(
                                    host = host,
                                    port = port.toIntOrNull() ?: 14550
                                )
                                connectionManager.connect(config)
                            } else {
                                connectionManager.disconnect()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        val buttonText = when (connectionState) {
                            ConnectionState.DISCONNECTED, ConnectionState.ERROR -> 
                                stringResource(R.string.connect_button)
                            ConnectionState.CONNECTING -> "Connecting..."
                            ConnectionState.CONNECTED -> 
                                stringResource(R.string.disconnect_button)
                        }
                        Text(buttonText)
                    }
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = getConnectionStatusText(connectionState),
                        style = MaterialTheme.typography.bodyMedium,
                        color = getConnectionStatusColor(connectionState)
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Connection Instructions:",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium
        )
        
        Text(
            text = """
                1. Start your flight simulator or connect to a real vehicle
                2. Configure the host IP and port (defaults: 127.0.0.1:14550)
                3. Click Connect to establish UDP connection
                4. Monitor connection status and switch to Fly tab for flight data
            """.trimIndent(),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun getConnectionStatusText(state: ConnectionState): String {
    return when (state) {
        ConnectionState.DISCONNECTED -> stringResource(R.string.connection_status_disconnected)
        ConnectionState.CONNECTING -> stringResource(R.string.connection_status_connecting)
        ConnectionState.CONNECTED -> stringResource(R.string.connection_status_connected)
        ConnectionState.ERROR -> stringResource(R.string.connection_status_error)
    }
}

@Composable
private fun getConnectionStatusColor(state: ConnectionState) = when (state) {
    ConnectionState.DISCONNECTED -> MaterialTheme.colorScheme.onSurfaceVariant
    ConnectionState.CONNECTING -> MaterialTheme.colorScheme.primary
    ConnectionState.CONNECTED -> MaterialTheme.colorScheme.primary
    ConnectionState.ERROR -> MaterialTheme.colorScheme.error
}