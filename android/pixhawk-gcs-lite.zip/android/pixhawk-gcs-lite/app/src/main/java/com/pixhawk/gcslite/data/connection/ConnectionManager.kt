package com.pixhawk.gcslite.data.connection

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.DatagramSocket
import java.net.InetSocketAddress
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import android.util.Log

class ConnectionManager {
    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()
    
    private val _vehicleState = MutableStateFlow(VehicleState())
    val vehicleState: StateFlow<VehicleState> = _vehicleState.asStateFlow()
    
    private var socket: DatagramSocket? = null
    private var isRunning = false
    
    fun connect(config: UdpConnectionConfig) {
        if (_connectionState.value == ConnectionState.CONNECTING || 
            _connectionState.value == ConnectionState.CONNECTED) {
            return
        }
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                _connectionState.value = ConnectionState.CONNECTING
                
                // Simulate connection process
                delay(2000) // Simulate connection delay
                
                // Create UDP socket
                socket = DatagramSocket()
                socket?.connect(InetSocketAddress(config.host, config.port))
                
                _connectionState.value = ConnectionState.CONNECTED
                _vehicleState.value = _vehicleState.value.copy(isConnected = true)
                
                isRunning = true
                startHeartbeatSimulation()
                
                Log.d("ConnectionManager", "Connected to ${config.host}:${config.port}")
                
            } catch (e: Exception) {
                Log.e("ConnectionManager", "Connection failed", e)
                _connectionState.value = ConnectionState.ERROR
                _vehicleState.value = _vehicleState.value.copy(isConnected = false)
            }
        }
    }
    
    fun disconnect() {
        isRunning = false
        socket?.close()
        socket = null
        _connectionState.value = ConnectionState.DISCONNECTED
        _vehicleState.value = VehicleState() // Reset to default state
        Log.d("ConnectionManager", "Disconnected")
    }
    
    private suspend fun startHeartbeatSimulation() {
        // Simulate receiving heartbeat messages and updating vehicle state
        var counter = 0
        while (isRunning) {
            delay(1000) // Simulate 1Hz heartbeat
            
            if (_connectionState.value == ConnectionState.CONNECTED) {
                // Simulate changing vehicle state over time
                val modes = listOf("MANUAL", "STABILIZE", "ALT_HOLD", "AUTO", "GUIDED")
                val currentMode = modes[counter % modes.size]
                val isArmed = (counter / 5) % 2 == 1 // Toggle armed state every 5 seconds
                val battery = 12.0f - (counter * 0.01f) // Simulate battery drain
                val sats = minOf(10, counter / 2) // Simulate GPS satellites increasing
                val link = maxOf(50, 100 - (counter % 20)) // Simulate link quality fluctuation
                
                _vehicleState.value = _vehicleState.value.copy(
                    mode = currentMode,
                    isArmed = isArmed,
                    batteryVoltage = battery,
                    satelliteCount = sats,
                    linkQuality = link
                )
                
                counter++
            }
        }
    }
}