package com.pixhawk.gcslite.data.mavlink

import io.dronefleet.mavlink.MavlinkMessage
import io.dronefleet.mavlink.common.Heartbeat
import io.dronefleet.mavlink.common.MavAutopilot
import io.dronefleet.mavlink.common.MavModeFlag
import io.dronefleet.mavlink.common.MavState
import io.dronefleet.mavlink.common.MavType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import android.util.Log
import com.pixhawk.gcslite.data.connection.VehicleState

class MavlinkProcessor {
    private val _vehicleState = MutableStateFlow(VehicleState())
    val vehicleState: StateFlow<VehicleState> = _vehicleState.asStateFlow()
    
    fun processMessage(message: MavlinkMessage<*>) {
        when (val payload = message.payload) {
            is Heartbeat -> processHeartbeat(payload)
            else -> {
                // Handle other message types as needed
                Log.d("MavlinkProcessor", "Received message: ${payload.javaClass.simpleName}")
            }
        }
    }
    
    private fun processHeartbeat(heartbeat: Heartbeat) {
        try {
            val isArmed = (heartbeat.baseMode().entry() and MavModeFlag.MAV_MODE_FLAG_SAFETY_ARMED.entry()) != 0
            val mode = getModeString(heartbeat.customMode())
            val systemStatus = heartbeat.systemStatus().entry()
            val isConnected = systemStatus != MavState.MAV_STATE_POWEROFF.entry()
            
            _vehicleState.value = _vehicleState.value.copy(
                isConnected = isConnected,
                isArmed = isArmed,
                mode = mode
            )
            
            Log.d("MavlinkProcessor", "Heartbeat processed - Armed: $isArmed, Mode: $mode")
        } catch (e: Exception) {
            Log.e("MavlinkProcessor", "Error processing heartbeat", e)
        }
    }
    
    private fun getModeString(customMode: Long): String {
        // This is a simplified mode mapping for ArduPilot
        // In a real implementation, you'd want to use the proper mode mapping
        // based on the vehicle type and autopilot
        return when (customMode.toInt()) {
            0 -> "MANUAL"
            1 -> "CIRCLE"
            2 -> "STABILIZE"
            3 -> "TRAINING"
            4 -> "ACRO"
            5 -> "FLY_BY_WIRE_A"
            6 -> "FLY_BY_WIRE_B"
            7 -> "CRUISE"
            8 -> "AUTOTUNE"
            10 -> "AUTO"
            11 -> "RTL"
            12 -> "LOITER"
            15 -> "GUIDED"
            16 -> "INITIALISING"
            17 -> "QSTABILIZE"
            18 -> "QHOVER"
            19 -> "QLOITER"
            20 -> "QLAND"
            21 -> "QRTL"
            22 -> "QAUTOTUNE"
            23 -> "QACRO"
            else -> "UNKNOWN($customMode)"
        }
    }
    
    fun createHeartbeat(): Heartbeat {
        // Create a GCS heartbeat to send to the vehicle
        return Heartbeat.builder()
            .type(MavType.MAV_TYPE_GCS)
            .autopilot(MavAutopilot.MAV_AUTOPILOT_INVALID)
            .baseMode(0)
            .customMode(0)
            .systemStatus(MavState.MAV_STATE_ACTIVE)
            .mavlinkVersion(3)
            .build()
    }
}