package com.pixhawk.gcslite.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pixhawk.gcslite.R
import com.pixhawk.gcslite.ui.screens.ConnectScreen
import com.pixhawk.gcslite.ui.screens.FlyScreen
import com.pixhawk.gcslite.ui.screens.LogsScreen
import com.pixhawk.gcslite.ui.screens.MissionsScreen
import com.pixhawk.gcslite.ui.screens.ParamsScreen
import com.pixhawk.gcslite.ui.screens.SettingsScreen

@Composable
fun MainNavigation(
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    
    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                Screen.entries.forEach { screen ->
                    NavigationBarItem(
                        icon = { 
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title
                            )
                        },
                        label = { Text(screen.title) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                // Pop up to the start destination of the graph to
                                // avoid building up a large stack of destinations
                                // on the back stack as users select items
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                // Avoid multiple copies of the same destination when
                                // reselecting the same item
                                launchSingleTop = true
                                // Restore state when reselecting a previously selected item
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.CONNECT.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.CONNECT.route) {
                ConnectScreen()
            }
            composable(Screen.FLY.route) {
                FlyScreen()
            }
            composable(Screen.MISSIONS.route) {
                MissionsScreen()
            }
            composable(Screen.PARAMS.route) {
                ParamsScreen()
            }
            composable(Screen.LOGS.route) {
                LogsScreen()
            }
            composable(Screen.SETTINGS.route) {
                SettingsScreen()
            }
        }
    }
}