package com.pixhawk.gcslite.data.connection

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR
}

data class UdpConnectionConfig(
    val host: String = "127.0.0.1",
    val port: Int = 14550
)

data class VehicleState(
    val isConnected: Boolean = false,
    val isArmed: Boolean = false,
    val mode: String = "Unknown",
    val batteryVoltage: Float? = null,
    val satelliteCount: Int = 0,
    val linkQuality: Int = 0
)