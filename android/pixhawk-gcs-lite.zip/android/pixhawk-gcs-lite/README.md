# Pixhawk GCS Lite

A lightweight Android Ground Control Station application for Pixhawk autopilots and compatible vehicles.

## Features

- **UDP Connection**: Connect to vehicles over UDP (default: 127.0.0.1:14550)
- **MAVLink Integration**: Real-time vehicle communication using MAVLink protocol
- **Flight Display**: HUD showing mode, armed status, battery, GPS satellites, and link quality
- **Google Maps Integration**: Map view for vehicle location and mission planning
- **Material 3 UI**: Modern Android UI with light/dark theme support
- **Bottom Navigation**: Easy access to Connect, Fly, Missions, Params, Logs, and Settings

## Setup Instructions

### Prerequisites
- Android Studio (latest version recommended)
- Android SDK API 34
- JDK 17 or higher

### Opening the Project
1. Extract the ZIP file to your desired location
2. Open Android Studio
3. Select "Open an Existing Project"
4. Navigate to the extracted `pixhawk-gcs-lite` folder
5. Click "OK" to open the project

### Google Maps API Key (Optional)
The app will run without a Google Maps API key, but maps functionality will be limited.

To enable Google Maps:
1. Get an API key from [Google Cloud Console](https://console.cloud.google.com/)
2. Enable the "Maps SDK for Android" API
3. Add the API key to your `local.properties` file:
   ```
   MAPS_API_KEY=your_api_key_here
   ```

### Building the App
1. Sync the project (Android Studio will prompt you)
2. Build the app using "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)"
3. Install on device/emulator using "Run" > "Run 'app'"

## Usage

### Connecting to a Vehicle
1. Launch the app
2. Navigate to the "Connect" tab (default)
3. Configure UDP settings:
   - Host: IP address of the vehicle (default: 127.0.0.1 for SITL)
   - Port: UDP port (default: 14550)
4. Tap "Connect"

### Flight Display
1. Once connected, navigate to the "Fly" tab
2. View real-time flight data:
   - Flight mode
   - Armed/disarmed status
   - Link quality
   - Battery voltage
   - GPS satellite count
   - Connection status
3. Map view shows vehicle location (requires API key)

### Other Tabs
- **Missions**: Mission planning (coming soon)
- **Params**: Parameter configuration (coming soon)
- **Logs**: Flight log analysis (coming soon)
- **Settings**: App configuration (coming soon)

## Technical Details

### Tech Stack
- **Language**: Kotlin
- **UI Framework**: Jetpack Compose with Material 3
- **Navigation**: Navigation Compose
- **Networking**: UDP Sockets
- **MAVLink**: io.dronefleet:mavlink library
- **Maps**: Google Maps Compose
- **Async**: Kotlin Coroutines & Flow

### Architecture
- **MVVM Pattern**: Using StateFlow for reactive UI updates
- **Modular Design**: Separated data, UI, and navigation layers
- **Connection Management**: Centralized ConnectionManager for vehicle communication
- **MAVLink Processing**: Dedicated MavlinkProcessor for message handling

### Requirements
- **Min SDK**: 26 (Android 8.0)
- **Target SDK**: 34 (Android 14)
- **Permissions**: Internet, Network State, Location (Fine & Coarse)

## Development

### Project Structure
```
app/
├── src/main/
│   ├── java/com/pixhawk/gcslite/
│   │   ├── data/
│   │   │   ├── connection/     # Connection management
│   │   │   └── mavlink/        # MAVLink processing
│   │   ├── ui/
│   │   │   ├── navigation/     # Navigation setup
│   │   │   ├── screens/        # App screens
│   │   │   └── theme/          # Material 3 theming
│   │   └── MainActivity.kt
│   ├── res/                    # Android resources
│   └── AndroidManifest.xml
└── build.gradle.kts
```

### Testing
Basic instrumented tests are included. Run tests using:
```bash
./gradlew test
./gradlew connectedAndroidTest
```

## Troubleshooting

### Common Issues

1. **Build Errors**: 
   - Ensure you have the latest Android Studio
   - Sync project and clean/rebuild

2. **Connection Issues**:
   - Check host/port configuration
   - Ensure vehicle is broadcasting MAVLink on the specified port
   - For SITL, use 127.0.0.1:14550

3. **Maps Not Working**:
   - Add Google Maps API key to local.properties
   - Enable Maps SDK for Android in Google Cloud Console

## Contributing

This is a basic implementation with room for enhancement:
- Mission planning functionality
- Parameter management
- Flight log analysis
- Advanced telemetry displays
- Joystick/RC control

## License

This project is provided as-is for educational and development purposes.